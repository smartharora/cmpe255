import CustomNavbar from "../component/navbar";
import React from 'react';
import UserCountGraph from "../component/UserCountGraph";
const AdminDashBoard = ()=>{
    const [activeKey, setActiveKey] = React.useState("subscription");

    return (
        <>
        <CustomNavbar activeKey={activeKey} onSelect={setActiveKey} />
        <UserCountGraph />
        </>
    );
}

export default AdminDashBoard;