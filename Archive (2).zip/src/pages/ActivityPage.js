import { Container, FlexboxGrid } from "rsuite";
import ActivityForm from "../component/ActivityForm";
import CustomNavbar from "../component/navbar";
import React from 'react';
import ActivityTable from "../component/ActivityTable";
import CheckInActivityTable from "../component/checkInActivityTable";

const ActivityPage = () => {
    const [activeKey, setActiveKey] = React.useState("log-activity");

    return (
        <>
            <CustomNavbar activeKey={activeKey} onSelect={setActiveKey} />
            <Container>
                <ActivityForm />
                 <FlexboxGrid>
                    <FlexboxGrid.Item colspan={12}> <ActivityTable /></FlexboxGrid.Item>
                    <FlexboxGrid.Item colspan={12}> <CheckInActivityTable /></FlexboxGrid.Item>
                </FlexboxGrid>
            </Container>
            <Container>
               
            </Container>
        </>
    );
}

export default ActivityPage;

